import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-administrator-page',
  templateUrl: './administrator-page.component.html',
  styleUrls: ['./administrator-page.component.css']
})
export class AdministratorPageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
