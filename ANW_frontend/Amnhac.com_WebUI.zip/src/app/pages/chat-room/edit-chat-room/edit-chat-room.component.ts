import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-edit-chat-room',
  templateUrl: './edit-chat-room.component.html',
  styleUrls: ['./edit-chat-room.component.css']
})
export class EditChatRoomComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
