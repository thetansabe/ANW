export class RankingCategory{
    Id: string;
    Name: string;
    TypeList: string[];
}