export class Nation{
    Id:string;
    Name: string;
}
