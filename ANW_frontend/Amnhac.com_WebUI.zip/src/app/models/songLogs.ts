export class SongLogs{
    SongId: string;
    ViewCount: number;
    CreatedOn: Date;
}