export class Slider{
    Id :any;
    Title: string;
    Desc: string;
    Path: string;
    Goto: string;
    Alignment: string;
    ValidFrom: Date;
    ValidTo: Date;
}