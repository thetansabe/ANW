export class Artist{
    Id: string;
    Name: string;
    Desc: string;
    AvatarImg: string;
    BackgroundImg: string;
    BelongTo: string;
    DateOfBirth:Date;
    Page: string;
    Country: string;
    CountryName: string;
}