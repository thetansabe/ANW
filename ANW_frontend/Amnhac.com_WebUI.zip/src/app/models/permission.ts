export class Permission {
    Id: string;
    Name: string;
    Desc: string;
    Color: string;
    Price: number;
    Category: number;
}