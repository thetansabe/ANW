export class SongType{
    Id:any;
    Text: string;
    SubType: SongSubType[];
}

export class SongSubType{
    Id:any;
    Text: string;
}