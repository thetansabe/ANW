export class SystemConfig{
    Id: string;
    CategoryToChart: string;
}