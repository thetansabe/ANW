export enum GuardLevel{
    FREE_USER=0,
    PRO=3,
    ARTIST=6,
    MANAGER=9,
    ADMINISTRATOR=10
}