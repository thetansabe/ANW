import { Vietnamese } from './vi-VI/vietnamese';

export const locale={
    language: Vietnamese
}